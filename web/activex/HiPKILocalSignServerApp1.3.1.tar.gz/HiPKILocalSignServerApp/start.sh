#!/bin/bash
cd HiPKILocalSignServer
pwd
./node hipkiLocalServer.js

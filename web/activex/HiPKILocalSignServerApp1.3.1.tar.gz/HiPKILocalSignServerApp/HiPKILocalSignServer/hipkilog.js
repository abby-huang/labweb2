var winston = require('winston');

var logger = new (winston.Logger)({
  transports: [
    new (winston.transports.Console)({ json: false, timestamp: true }),
    new winston.transports.DailyRotateFile({ filename: __dirname + '/debug.log', json: false, datePattern: '.yyyy-MM-dd', maxFiles:30 })
  ],
  exceptionHandlers: [
    new (winston.transports.Console)({ json: false, timestamp: true }),
    new winston.transports.DailyRotateFile({ filename: __dirname + '/exceptions.log', json: false, datePattern: '.yyyy-MM-dd',handleExceptions: true,
    humanReadableUnhandledException: true, maxFiles:30 })
  ],
  exitOnError: false
});

module.exports = logger;

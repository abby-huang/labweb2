var querystring = require('querystring'); 
var child_process = require('child_process');
var logger = require('./hipkilog');
var serverVersion="1.3.1";
const fs=require('fs');
var errorcode = require("./errorcode");
var url = require('url');
var nonce=Math.floor((Math.random() * 9000) + 1000);
var UNAUTHORIZED_DOMAIN = 0x76000031;
var cacheCardSn;
var cacheCert,cacheCert2;
/**
 * Global variables
 */
function sendParentMessageOutput(response, msg){
	response.writeHead(200, {"Content-Type": "text/html; charset=utf-8"});
	response.write('<!DOCTYPE html><html><head><meta charset="utf-8"><script>var postTarget=window.parent;if(window.opener!=null) postTarget=window.opener;\npostTarget.postMessage(\''+msg.trim()+'\',"*");');
	response.write('window.close();');
	response.write('</script></head><body></body></html>');
	response.end();
}
function outputDirect(response, msg){
	response.writeHead(200, {"Content-Type": "text/plain; charset=utf-8"});
	response.write(msg);
	response.end();
}
var method="POST";
var action="#";
var signedData="ResultSignedData";
var errorAction="#";

/*{
	//must
	tbs: 'tbs',
	pin: 'pin',
	//optional
	nonce: 'nonce',
	withSigningTime: true,
	withCardID: false,
	digestAlgorithm: "SHA256",
	slotName: ""
}
{
	ret_code:0,
	last_error:0,
	signature:""
}
*/
function sign(request, response) {
    //console.log("Handler 'sign' is started.");
	//logger.info(request.headers['user-agent']);
	if (request.method == 'POST') {
        var body = '';
        request.on('data', function (data) {
            body += data;
        });
        request.on('end', function () {
            allPost = querystring.parse(body);
			post=JSON.parse(allPost["tbsPackage"]);
			
			var exedir = __dirname;
			if(!(post["tbs"]) || !(post["pin"])){
				response.writeHead(400, {"Content-Type": "text/plain"});
				response.write("require tbs and pin");
				response.end();
			}else{
				if(process.cwd().toUpperCase() === "C:\\Windows\\system32".toUpperCase()){
					exedir = process.env.HOME;
					//response.write("service\n");
				}else{
					//response.write("standalone\n");
				}
				var exereq = {};
				exereq["pin"] = post["pin"];
				if(post["tbsEncoding"] && post["tbsEncoding"]==='base64') //already base64 encoded
				{
						exereq["tbs"] = post["tbs"];
				}else exereq["tbs"] = new Buffer(post["tbs"]).toString('base64');
				if(post["hashAlgorithm"]){
					exereq["hashAlgorithm"] = post["hashAlgorithm"];
				}
				if(post["nonce"]){
					exereq["nonce"] = post["nonce"];
				}
				if(post["withSigningTime"]){
					exereq["withSigningTime"] = (post["withSigningTime"] === 'true');
				}
				if(post["withCardSN"]){
					exereq["withCardSN"] = (post["withCardSN"] === 'true');
				}
				if(post["slotDescription"]){
					exereq["slotDescription"] = post["slotDescription"];
				}
				if(post["signatureType"]){  //PKCS1 or PKCS7
					exereq["signatureType"] = post["signatureType"];
				}
				if(cacheCardSn && cacheCert){
					exereq["cardSN"]=cacheCardSn;
					exereq["certb64"]=cacheCert;
				}
				var jsons = JSON.stringify(exereq);
				console.log(jsons);
				child_process.execFile(exedir+"/HiPKISign.exe", [jsons], {"encoding": 'utf8', "timeout": 20000},function(error, stdout, stderr){
					if (error !== null) {
						console.log('stderr: ' + stderr);
						console.log('exec error: ' + error);
						logger.error(error);
						logger.error(stderr);
						var errJ = {"ret_code":0x7600000D,"func":"sign","message":errorcode.MajorErrorReason(0x7600000D),"serverVersion":serverVersion};
						outputDirect(response, JSON.stringify(errJ));
					  //err.code
					}else{
						console.log("HiPKISign.exe done, callback");
						console.log('stdout: ' + stdout);
						//logger.info('stdout: ');
						logger.info(stdout);
						var resultJson = JSON.parse(stdout);
						if(resultJson["ret_code"]!=0){
							resultJson["message"]=errorcode.MajorErrorReason(resultJson["ret_code"]);
							if(resultJson["last_error"])
								resultJson["message2"]=errorcode.MinorErrorReason(resultJson["last_error"]);
							outputDirect(response,JSON.stringify(resultJson));
						}else{
							cacheCardSn=resultJson.cardSN;
							if(cacheCardSn.match('(MT|MG|TT|TTA)\\d+$'))
							{ //read Authorized Attribute
							}
							cacheCert=resultJson.certb64;
							outputDirect(response, stdout);
						}
					}
				});
			}
        });
    }else{
		response.writeHead(405, {"Content-Type": "text/plain"});
		response.write("POST allowed only");
		response.end();
	}
	
}
function getCaptcha(request,response){
	var query=url.parse(request.url,true).query;
	var imgNo;
	if(query.digit=="1"){
		imgNo=(nonce-nonce%1000)/1000;
	}else if(query.digit=="2"){
		imgNo=((nonce-nonce%100)/100)%10;
	}else if(query.digit=="3"){
		imgNo=((nonce-nonce%10)/10)%10;
	}else if(query.digit=="4"){
		imgNo=nonce%10;
	}else{
		response.writeHead(404, {"Content-Type": "text/plain"});
		response.write("404 Not Found\n");
		response.end();		
		return;
	}
	response.writeHead(200, {'Content-Type': 'image/png' });
	response.writeHead(200,{'Cache-Control': 'no-cache, no-store, must-revalidate'});
	//logger.info("nonce="+nonce+" imgNo="+imgNo);
	var img=fs.readFileSync(__dirname+'/digits/'+imgNo+'.png');
	response.end(img, 'binary');
}
function addDomain(request,response)
{
	var output={};
	if (request.method == 'POST') {
        var body = '';
        request.on('data', function (data) {
            body += data;
        });
        request.on('end', function () {
            allPost = querystring.parse(body);
			post=JSON.parse(allPost["submitData"]);
			if(post["nonce"]==nonce){//Verify successful
				logger.info('Add '+post["domain"]+' to white list.');
				output["ret_code"]=0;
				fs.appendFileSync(__dirname+'/whiteList.txt','\n'+post["domain"]);
			}else{
				output["ret_code"]=0x7600000F;
				output["message"]=errorcode.MajorErrorReason(0x7600000F);
			}
			nonce=Math.floor((Math.random() * 9000) + 1000);
			outputDirect(response,JSON.stringify(output));
		});
	}else { //get method, return normal html
		response.writeHead(200, {"Content-Type": "text/html; charset=utf-8"});
		var query=url.parse(request.url,true).query;
		if(query.domain)
		{
			var htm=fs.readFileSync(__dirname+'/addDomain.htm','utf8');
			response.write(htm.replace(/%domain%/g,query.domain)) ;
			response.end();
		}else
		{
			response.write('<html><head></head><body><script type="text/javascript">alert("No domain found");window.close();</script></body></html>');
			response.end();
		}
	}
}
function decrypt(request, response) {
    //console.log("Handler 'sign' is started.");
	//logger.info(request.headers['user-agent']);
	if (request.method == 'POST') {
        var body = '';
        request.on('data', function (data) {
            body += data;
        });
        request.on('end', function () {
            allPost = querystring.parse(body);
			post=JSON.parse(allPost["tbsPackage"]);
			//logger.info(allPost["tbsPackage"]);
			//logger.info(post["cipher"]);
			
			var exedir = __dirname;
			if(!(post["cipher"]) || !(post["pin"])){
				response.writeHead(400, {"Content-Type": "text/plain"});
				response.write("require cipher and pin");
				response.end();
			}else{
				if(process.cwd().toUpperCase() === "C:\\Windows\\system32".toUpperCase()){
					exedir = process.env.HOME;
					//response.write("service\n");
				}else{
					//response.write("standalone\n");
				}
				var exereq = {};
				exereq["pin"] = post["pin"];
				exereq["cipher"] = post["cipher"];
				if(post["slotDescription"]){
					exereq["slotDescription"] = post["slotDescription"];
				}
				if(post["cipherType"]){  //PKCS1 or PKCS7
					exereq["cipherType"] = post["cipherType"];
				}
				if(cacheCardSn && cacheCert2){
					exereq["cardSN"]=cacheCardSn;
					exereq["certb64"]=cacheCert2;
				}
				var jsons = JSON.stringify(exereq);
				console.log(jsons);
				child_process.execFile(exedir+"/HiPKIDecrypt.exe", [jsons], {"encoding": 'utf8', "timeout": 20000},function(error, stdout, stderr){
					if (error !== null) {
						console.log('stderr: ' + stderr);
						console.log('exec error: ' + error);
						logger.error(error);
						logger.error(stderr);
						var errJ = {"ret_code":0x7600000D,"func":"decrypt","message":errorcode.MajorErrorReason(0x7600000D),"serverVersion":serverVersion};
						
						outputDirect(response, JSON.stringify(errJ));
					  //err.code
					}else{
						console.log("HiPKIDecrypt.exe done, callback");
						console.log('stdout: ' + stdout);
						//logger.info('stdout: ');
						logger.info(stdout);
						var resultJson = JSON.parse(stdout);
						if(resultJson["ret_code"]!=0){
							resultJson["message"]=errorcode.MajorErrorReason(resultJson["ret_code"]);
							if(resultJson["last_error"])
								resultJson["message2"]=errorcode.MinorErrorReason(resultJson["last_error"]);
							outputDirect(response,JSON.stringify(resultJson));
						}else{
							if(post["plainEncoding"] && post["plainEncoding"]!='base64') //plain input
							resultJson["plain"] = 	new Buffer(resultJson["plain"], 'base64').toString();
							cacheCardSn=resultJson.cardSN;
							cacheCert2=resultJson.certb64;
							outputDirect(response, JSON.stringify(resultJson));
						}
					}
				});
			}
        });
    }else{
		response.writeHead(405, {"Content-Type": "text/plain"});
		response.write("POST allowed only");
		response.end();
	}
	
}

function getP11Info(withcert)
{
	var exedir = __dirname;
	if(process.cwd().toUpperCase() === "C:\\Windows\\system32".toUpperCase()){
		exedir = process.env.HOME;
		//response.write("service\n");
	}else{
		//response.write("standalone\n");
	}
	var arg="";
	if(withcert) arg="-withcert";
	try{
		var stdout=child_process.execFileSync(exedir+"/ListInfo.exe", [arg], {"encoding": 'utf8', "timeout": 30000});
		console.log('stdout: ' + stdout);
		logger.info(stdout);
		var outData=JSON.parse(stdout);
		outData["serverVersion"]=serverVersion;
		var resultJson = JSON.stringify(outData);
		return resultJson;
	}catch(error){
		console.log('exec error: ' + error);
		logger.error(error);
		var output={};
		output["ret_code"]=0x7600000D;
		output["message"]=errorcode.MajorErrorReason(0x7600000D);
		outData["serverVersion"]=serverVersion;
		return JSON.stringify(output);
	}
}

function pkcs11info(request, response) {
    //console.log("Handler 'pkcs11info' is started.");
	var query=url.parse(request.url,true).query;
	var result;
	if(query.withcert==="true") result=getP11Info(true);
	else result=getP11Info(false);
	outputDirect(response,result);
	return;
}

function popupForm(request,response){
	var exedir = __dirname;
	var whiteList=fs.readFileSync(exedir+'/whiteList.txt', 'utf8').split(/\r\n|\r|\n/);
	var matchstr=whiteList[0];
	for(i=1;i<whiteList.length;i++){
		matchstr=matchstr+"|"+whiteList[i];
	}
	response.writeHead(200, {"Content-Type": "text/html; charset=utf-8"});
	var htm=fs.readFileSync(__dirname+'/popupForm.htm','utf8');
	htm=htm.replace(/%matchstr%/g,matchstr);
	response.write(htm);
	response.end();
}
function sendImage(resultJson,response){
	while(resultJson.length%3!=0) resultJson=resultJson+" ";
	resultJson=new Buffer(resultJson).toString('base64');
	var imgstr1="Qk2mFwAAAAAAADYAAAAoAAAA0AcAAAEAAAABABgAAAAAAHAXAAAAAAAAAAAAAAAAAAAAAAAA";
	var imgstr2="////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
	imgstr2=resultJson+imgstr2.substring(resultJson.length);
	var img=new Buffer(imgstr1+imgstr2, 'base64');
	response.write(img, 'binary');
	response.end();
}

function getP11Image(request,response){
	var exedir = __dirname;
	var inWhiteList=false;
	var output={};
	if(process.cwd().toUpperCase() === "C:\\Windows\\system32".toUpperCase()){
		exedir = process.env.HOME;
		//response.write("service\n");
	}else{
		//response.write("standalone\n");
	}
	response.writeHead(200, {'Content-Type': 'image/x-windows-bmp' });
	response.writeHead(200,{'Cache-Control': 'no-cache, no-store, must-revalidate'});
	var whiteList=fs.readFileSync(exedir+'/whiteList.txt', 'utf8').split(/\r\n|\r|\n/);
	var origin=request.headers.origin;
	if(origin!=null)
	{
		for(i=0;i<whiteList.length;i++){
			if(origin.match('(http:\\/\\/|https:\\/\\/)'+whiteList[i]+'($|:\\d+$)')!=null)
			{
				response.writeHead(200, {"Access-Control-Allow-Origin": request.headers.origin});
				inWhiteList=true;
			}
		}
	}
	if(inWhiteList==false){
		response.writeHead(200, {"Access-Control-Allow-Origin": request.headers.origin});
		output["ret_code"]=UNAUTHORIZED_DOMAIN;
		output["serverVersion"]=serverVersion;
		sendImage(JSON.stringify(output),response);
		return;
	}
	var result=getP11Info(false);
	sendImage(result,response);
}
function selfTest(request,response){
	var exedir = __dirname;
	response.writeHead(200, {"Content-Type": "text/html; charset=utf-8"});
	var htm=fs.readFileSync(__dirname+'/selfTest.htm','utf8');
	response.write(htm);
	response.end();
}

exports.sign = sign;
exports.pkcs11info = pkcs11info;
exports.popupForm=popupForm;
exports.p11Image=getP11Image;
exports.serverVersion=serverVersion;
exports.getCaptcha=getCaptcha;
exports.addDomain=addDomain;
exports.decrypt=decrypt;
exports.selfTest=selfTest;
var http = require("http");
var url = require("url");
var hipkiFuncs = require("./hipkiFuncs");

var serverIP="127.0.0.1";
var serverPort=61161;
var logger = require('./hipkilog');
var fs=require('fs');

var handlers = {
   "/": serverInfo,
   "/sign": hipkiFuncs.sign,
   "/pkcs11info": hipkiFuncs.pkcs11info,
   "/test": hipkiFuncs.test,
   "/favicon.ico":favicon,
   "/popupForm":hipkiFuncs.popupForm,
   "/waiting.gif":waiting,
   "/getCaptcha.png":hipkiFuncs.getCaptcha,
   "/addDomain":hipkiFuncs.addDomain,
   "/p11Image.bmp":hipkiFuncs.p11Image,
   "/selfTest.htm":hipkiFuncs.selfTest,
   "/decrypt":hipkiFuncs.decrypt
};

function route(pathname, handlers, query, response) {
    // 檢查 pathname 是否有對應的 request handlers
    if (typeof handlers[pathname] === "function") {
        handlers[pathname](query, response);
		return;
    }
	var uri=pathname.split("/");
	if(uri.length==3)
	{
		try{
			var moduleInfo=fs.statSync(__dirname+'/Module_'+uri[1]+'.txt');
			if(moduleInfo.isFile())
			{
				var moduleFunc=require("../"+uri[1]+"/module.js");
				logger.info("Module "+uri[1]+" loaded");
				moduleFunc.handle(pathname,query,response);
			}
			return;
		}catch(err)
		{
			console.log("Module error:"+err);
			response.writeHead(404, {"Content-Type": "text/plain"});
			response.write("404 Not found");
			response.end();
			return;
		}
	}
	//No matched handler return 404
	console.log("No request handler for this pathname: '" + pathname + "'");
	response.writeHead(404, {"Content-Type": "text/plain"});
	response.write("404 Not found");
	response.end();
}

function start(route, handlers) {
  function onRequest(request, response) {
    var pathname = url.parse(request.url).pathname;
    route(pathname, handlers, request, response);
  }

  http.createServer(onRequest).listen(serverPort, serverIP);
  console.log("Server has started at "+serverIP+":"+serverPort);
}

function serverInfo(request, response) {
	response.writeHead(200, {"Content-Type": "text/plain"});
	response.write("HiPKI Local Server (version:"+hipkiFuncs.serverVersion+") at "+serverIP+":"+serverPort);
	response.end();
}

function favicon(request, response) {
	var img = new Buffer("AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//////v7+//7+/v/7/f3/8+zj/+y5jf/uizL/7nQE/+10Bf/ugB//7aZm//Ps4v/8/fr//f38//7+/v////////////3+/v/39u//8MKW//LBkv/zvpL/65A5/+51BP/udAT/7nQF/+tzCP/rpmP/68GS//Xz7P/9/v3//v7+///////7+/n/9Ozj//bWv//31sD/9da//+mYSf/vdAT/73UE/+91BP/vdQT/7XQE/+mXSv/x5tn/+Pv6//39/v/6+/z/7cGZ//CaV//vnFj/75tX/++bV//vkUT/74w3/++MNv/sgiX/73UE/+5zBf/udgn/6JRK/+y8jv/5/Pv/9Onf//LNqv/zzq//9NCw//Tcxv/5+/z/+/39//v9/v/6/Pz/8cii/+91BP/vdAT/7XUE/+2qcf/0zK3/9+jc//Dhzv/0x6H/98eh//XJn//z5tb/+vv9/////////////f79//PHov/vdQT/73UE/+11BP/vl0j/8cef//Lgzf/pl07/74cv/+6EMP/t28L//P38//7+/v/+/v7//v7+//3+/P/zyKP/73UE/+91BP/sdAT/7nsb/++FMv/wlEv/8sei//PGpP/u1r3/+fz7//7+/v/9/v3/89rD//XJpP/1yKP/7alq/+91BP/ucwP/73UE/+WobP/0x6L/9cij//bJpP/3yKT/8NrA//v+/f///////P39/++lZP/tcwT/7nMF/+9yBv/udAP/7nUE/+eJMv/1yKD/9smj//fJo//srHT/7ppV/+/Gnv/7/v3///////3+/v/zpWP/7nQE/+91BP/udAP/7nQD/+p6Ef/tjDr/7plW/+6ZV//wqnT/8Ovh//Daxf/w49L//P39///+///8/vz/8KZk/+xzA//tcwP/7XME/+l5Ef/uwpv/9tvH//fcyP/228b/9Ozh//Xr3v/wu4z/8Mmk//v8/P/+/v7//f7+//bUt//1vpD/9L2Q//S7jv/yvI7/8ruP//K8jv/yvI3/8bqP//Pq3f/9/v7/7M2s//GbWP/s0LD//v39//////////////////39/f/u1bv/8Jta/++bWv/vm1r/8ZxY/+3Fnv/7/f3//v7+//r8+//18uv/8Na9//Xhz//6+/r////////////9/f3/8u3j//XYvf/32L3/99i+//Tq5v/6+/v//v7+///////9/v7/+vr4//PHoP/wwZf/8+nd//z9/P/9/f3/+/z8//Hk0f/xvpH/87+T//PDnP/49fD//f39//7+/v////////////7+/v/+/v7/9/v6/+3axf/ts37/7ptV/++aUP/ur3r/8NO8//r8+//+/v7//v7+//7+/v//////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==", 'base64');
	response.writeHead(200, {'Content-Type': 'image/x-icon' });
	response.writeHead(200, {"Access-Control-Allow-Origin": "*"});
    response.end(img, 'binary');
}
function waiting(request, response) {
	var img = new Buffer("R0lGODlhfAB8AIeTAIBAAIKCgrKMPNfDj8LCwmFhYePk0ptoIM62Xejo6I5WHrGMZ9PArcGig8ChTY5WEp9vQKl+MfPuzenfoN/PwNvJbfX46a2trYlPFJtpN8esVa2EW9XV1YhNCuPWgpVhLff39+Dg4JmZmdbDaKh9StvbvOHUkbWRUMerkd3dwoRGCZdjHLmWdNXOtMCgWruZRnFxcaN2Kq2FN/Hq5OHTes64of3899K9Y6J1R4ZJB42NjezxzvDs6JJbJMGia9nJucWpU5NeF+nerd/QcqR2Mufp3OXbmNG7lYNEA7eUQs3Nzevh2LWQbcKkT+HVyfz787m5ucyyW+TYi/z79KWlpejiuePZz/P24WhoaKFyJ8Kmip9wQKl+Od3Nb/X0851tPcuxWubb0ItRDZlnNdfEaa2FQMqymnl5eaZ6Lq+IOdXBZvDw8JJcJvDou/n25ImJibaRQMrKyp5tJNG6YdbCrpBYE6qAMvby2Orho+DVxra2totRF51sO8itVq+HYN7e3uTXt93MjqGhoZaWlu/n4LmWXqZ6TpRfIrydfe7v5d3NvefcldK+qs20neXazuXn2NS+cO3lr6V5OP///4WFhcXFxWVlZe3t7bCwsNvb2/f49OXl5Z2dncaskphkHL6eS3V1ddO9p6d7QJKSkpZhGujem9LS0rmWc76+vqioqO7mtd/fyW5ubsaqjrKLRH5+frSOacOlh/Tv0eHSw/r47ZxrOuTWhZdkMayDSubakIdKCbqaesOlVLyaSKR2K+LUf9S/ZdzKuZRfGOzjrIRGBe3k28SmUfT24aByQ5RfKvr6+sqvlYJDBLSPPpxrIs62YsGjUtzLbq2EXIpPDOPWhJdjMN/expdjI6+HOP39+tO+ZPHv7NvLvODRc+jq3YNFBLiUQ+zj2raTcMOlUOLXzOXZjvz6+fP35N7OcPn2841TD9jGarGKO/bz8ZNeKNfDsJFbFauBNOrhpItRGMmvWOnenu/nuIdKDsOkWaR3LKFyROvr6+Pj42tra/Pz8wAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQFHgD/ACwAAAAAfAB8AAAI/wD/CRSYLROUVKMSKlzIsKHDhxAjSpxIcWIqKJmyDdzIcQ3CiiBDihxJEmKqSxw5Khk0ikocfl5AyJxJs6bNmzhz6tzJs6dOL/ziUBk1SElKgZUSQvHJtKnTp1B1QklYKWWmhJn8Rd3KtavXq6MybczGaVQcr2jTqt2pZJQgjQKvXripLNuku3jz6t3Lt6/fv4ADC95rV5nNC2EHTj1LU9ngx5AjS56st2acUVAGDk1Qk7Lnz6AnZ6O5z+1AEaPWNA7NurXrvDT9ER2YsPPr27gnG56ZkPaomnZzCx/ud7fMhCj/1aYZnLhz58ZBJAzhRflv5s/1ZnM86ZKSSpnuJv8gQCDEXX6V4iS4O7p59ujTN2VbPjM7XhCZlHC4u6YSAQ52jVeeXZmQt153cZhy4Hs0TReCdNfNxB1xXtwFQhwExOGYF/4p4dgm5Jk3CQfkXTJJNn+Qx89dXvgDXYOjhBBCaRHKRFw2myihBHumlDiJMkoQoAQIkwj4x4k9VlLhJD0SsMaJmVTCwZK5wRdjCJvQJ5N7uCV5IIjlIUlAJS6CaZ4yGGo4CYdCbujfWezhZqWMIWi51kz+hMAZCCGQZ0pMAg4JAomVcJYAB5lsAkJ/QsoEJgcyFUhAJjJ5keidNTlYZ42YrhHkn4tiWMk+IPgjqmoJJHAJTl5csieJ5ZX/iiEBioLAD3mZxIQphHTaeaepIcoEK6X4ZbKqU15swsGqYArKKAH87HrclZvueomufWao2iUdatXVbn/4V6ukgtqq2lqa+tqVFyFU8sdMTRKbqLdqrRHCtv4RQKqtGe6ZVrqcerUPebQ66l8l5+oqraSQgsAtee+qBTCmksZxbCZxbKKwtDL5g7FqwBIAqsTUqgvVGnte0uSQLdLLMU0tguAFrHF4e8kfG0c1sVeeZizTPvk++PJODxOw5xoY5trVzl3BWkmtCUjp8tA4qRyxp+QhvHTJAUPlRZNPy3Qs1T3FdMmslYy9FdNdqZy1v2Qzhfa+Dq/NNVcyzoS1EufG/83UJpWk3XGUajfFtlNRT+qtPxz0DZUyjnF54o/RIX6sd+QpkbNPhzNlKcFKFP4U5JIXV3lT6BGMM1SdM+VPillH+3jpg53OE5gZ1sr63U8pvMmsxDY1IWi25+RPkHzD7FTrPJmiu8pKTL0T5K9BztQ+SjuqRPCc895Utqbs64XjPA1f/VP7OC26Tszn9DXB/5Ffvvnn+7RGlKDDzVP7OrWbdbk9oZ+cfAI08sQhK8vznlPupyKm1IVBPeGAlOhmOAXy5BKOS58DBWMDN0hAFROQAg1oIIV6qEICbrBBYLbTE5TpKlnL6l6vusYqJcSBA/vYHE9oxx5ZTOAX3QiiEP+FOIQhdOMX9ZAFDy3EFHsliXvss6BOBOSnEEgvJwJkjz2GyMUuctEePCyeTTAGP831hH812Ycp8kUe3U3PLxLwohzlOAQJFCeCoDOWDGVkspxcgow180npslEPI87xkFysxyB7EjXnXTEnaLxJi/ghu/LxZQqLQKQmhziERUyBL2KkybVqosNMSREnIchEAhLGlEtmcpOwDKInCdOUSyhLCfq7SSRlNqsE/WF9dNkLJmNJzE5+Ui+hrFQm1kiwhkVxhi1kI8R8Yr5svJKYxFwEl5IpkyARDDz7O+VNEvAHU8yKgjrhkjywyc5uyEM7PYnSDUMwyp3scibj28QfHln/E/PRop3tpAUyeYIyfupSnGkx3zUBGstFDLQp/liDQXnFRxrWhAMc+MMmMFjKmThBC1S6CyDgQAaGYvMOeRkNT8jJAVPY0Jk42eWsCJbLmuwCAI3IRjrewdMyAKAZTQiqIU16yHJUhiewIpgp7IlQmkhTazjhhgLmAYB7KGAZAMiqVrXaBaJq8pg/6gmY0nNApkJzJ17Yhz45oISl5sQJhohrXJ2giHccwQ4/DSo9vKpJlN6HoCHgxyUu4Y+OTuusa7GCExYbjklAYKtaRQNfEdkG2GDqnk1RgFYzYI4ZECIQSQBAE4ABjBGgY7JzxINl77RLHbk2YjlRLGNjAdmt/74AtXKUAl5UilaXuhaAB0WsTuA3qZ0gggnIbUUxeMqLoDp3tLj1Ig1Wu5OZksesFe0JcWF6k1oo4LuGmEQragsAO0RXunjhZqm8STDsVouga4jvGgwLM7uM1xVwyC8cynveLur2r2iVr3zd28eteBe84gXANTyxAgbzt79DnEB6d7XLiLqKH0LLyVQNgYExJBgXdghxBB4M4SBW9i7qvd8mVjlRir53J+acKTBlogAcgGALHm4AAEjgix7HgMQl9itvd5KtMUmJwBZ1KnHdaBMFfMAMyRiDMjaggg302Bc/Nm+Jg3hM9Q6KuG6FZFNnYkNTmCITv+SnZrM6Bn9gQP8fkyhHNyoADCD316go9kkCQtDS70DRJruMrxdiMlEF1MIJYxjDeEMxiTt0Aw1ZTcKWu+HXSUSFvi4ucNWYXBMzMAIE29iGF2qAl0XMgR2fOG2JHZrnnkQ0gcLVyRo2kR9xNSU4/5x0EAV6IqZwwJf7aHGmk4wn9pKHu2+8yzon/c5W98S6cciwmGOdE/bqh9PJnsRCz2uE4Hh5UeaEH2ynnd2ehMAUehL2TYIzzP7OstcLTECt0Rnccj/FH/SeHru3zddFHGPCPvFH4SQaTmoT9A/fkV+22z3ZReyAPd+2lZQSoO7D2puRvybYn8sXHEI2/BwAZ4q1f7nHFxOUjZX/UEIlhZeXOBLVjhB3isekGWYkuy5JHKipA5uTjS22E4x5ibgoQ+BNaT/z4jzB3tjWsM+oDC8bPgQiIpGoxKBDBYN4orXC621yiIYgaVt5YF46+MEQjrCEJ0yhdoRO5jg0/SmYpckmmjSmrVNziX9hYVSKrARs29wpRRaZ351CusFsh+01cZtS7c51TY/TgBlmvPAeyPPJWc8ruvqdASs+7HtnonEz+fqM/cYUfoBeK+Fa+RnHzCo8wQq4pHfKw5RAN39wvvNbwZyfMB17nKRuTEavoMF9UjQCROz2vZdJAmaK7JI7PidI65fYfJb8eMpuDU3iAPJxHxU1niv6har+/08KFDaZIHz73L+0TKI/pnyLn8xvw5Pdhi97tF0O/XcirO3Bpvrd0b8psDMq00d778cnleBWihcHkldwSLcVEjQ2TVJzvfcsV/Md/Qd3rNdEM6E+i6Jz0tIqMuE/RtMxHih8DegVuFMrawR6VJMA33EsNDN6GPh/UBEyxCIgUDU0sDIl63VsvOd8xAYV+5AgMgMC3hQxGFWC98YPzuMws1IrZ8ODJEODUfFqfGJA63cqi8IV3nIr/2F+maMV43NZGbgV/pAvtQI+MuNSCNQU6YNLTjgmq3I8wSItced5BxgTXuBNnMEogZRK/CCGG3MJfKYa+IOEuFIq6EF9FFaGXP+xD+cSKDHxKDLRJKSSI0qAiIWSVh0CKB2iGsmCf6tHhWsBK4gYK0ZYIvxSXPjRQODnLd40eKzliGjxR6HTTXIoK9qyisSSLcQCK7XCD0pgRXFzOPyQCciYjMq4jMzYjM6YjBI0JsmYNci4MtVoQMjoTdvzjNzYjc5IQcbojeI4juXUVshIM9coJOd4MMkYB9s4jvD4jOBoQccYj/bYjWyVcun4ju74jvf4j8s4j7FWjwBZkMj4BwaZkPAokEhHkAr5kBAZkZnAkF3nkBJ5kRi5kDAykBnZkR7JjRRpJ7T2kSRZkhSJGn3jBfJWkizZkWMjG4NAJ5tBE/fTkjYZkav/o3yjwAl0MhXAtZI3GZQF6ThtcQF0wgGjMBcwA5RC2ZTiSHI0gRiVQCeTIAijAHutMlhauZWb0JVduZVgGZZauQ/7sJVlSZZimZZquZZsyZbzZRk7+Qcysgn/ABYbh09oVYTKo4eSZDyk5D5FyJcdUyp6iZc4IYaFWRNgMZUysg8CQQBKUYCSWTZTMQp6QCfUQRAr0RKMOJmeaStCoRSYuQmTsBGX8BElkZqquZqpSQUcgJmZyRGTkAl6gJqseZu4eZuCcAGMiZnJcRQDMQn2ApvEWZzGeZzImZzKuZzMqZxPApwpoQx71pzUWZ3WeZ3WmQDKAJ3AuSZqhZ3gGZ7iCqmcm5BDpbkRAQEAIfkEBR4A/wAsDwANAF0AXQAACP8A/wkcSLCgwYMGlYEQmCDOPw4CQwiE+O8CFlaoBILYpwyhx48gQ4oc6IVDHFMCLxH4h/KfxIcCORUosPJfpX6vao7cyXOkMn8DK9n08m+NQIf/+AnMJHDUTCUCBc3EJJAf055Ys/77EydOx39Q/yX4B8KhUJcT/yl7VQDLH7UBCliiOAqLDqVa84JUFhbvVYpIL6H9x3QNqwIwjPLDUgAU0D/9EOPVS3lgpk1LBYbFTLAlZswclG6CUeCMQFQzRwmkMlOEQH+DzlbGesmhEqCXzo4lKHjTS4Ne9nEIK7WAnn+XQM1EqmemoNlYjWYmSBEiZ54JCHB6i7pAAIGjZ0L/gT5y38C3KcWSJ3kh8vF/Mr0D/adn8nqCTK/+Q1r9j3TymWACGmMFhAWFJaAgdR94A700mWALGiTCTIMIZMphBaQS4UAUVbIbSr9tONAmVIAiUQJnzKTDfPddF1YcQP0nokG7OYUYZ5mkwiJlcVTy0m6EzRgSB4dZclYIynEyW0tJVaWTkCBlQomGWylXQD/25RXWYOZBKdJ8mZBWACtMUrbGltd5OdIlKY7JpH48/YEecg7FAaGaOxGART8tXSICKxTttMlKZZpyJ547VVIdW6UdOuRAcQCJaF5QYGgJlTwFOtikWXU3pmxYnaUppzztw1YAc64ho0chKqEgqViZ/yLInagEoORHVymxmz+OwpqVKaNY0taoBW3JUq++9kRiZDOd8epBcCZLmSnCIkaFpB5d0lKI0mJVlw7RGrTPodh2ixVXA6kkArE9/pOmuZVtckEAwlJRUJpK+AevXmsI0uZMr5BrbJP75qXDTKVRkQlRBSXQ4aoF83TTG6h06dEaf3AbcU+jXgImB+9uXBkHqAzyCqg2KZGJxSLTJsgb/VSrZK/EtrwTozNhUaG7w6FsM1ZUIDgIJhz0GkK4P48UghJZJr2gP/v8kYAppnAQQrkRRjPOEAN10cQNQlZywSA6nAEDJyiHPFsF4ERAChIAvJCGDP8AA0Az/xjjyzoRxv+H8BsGIVvZEA8QA4A6xnSRDwBz2I33AbqgE2FzbbFyhggJWIXSwOt18U8dngg0AhJZOB4FAHRHGAImepiSySUQCwn6QGjoMsfdaBBDhtM9OZBDDgAAkIMz6MyhBgIACLBOFBXg2WNXlSA9Gxi+xADANL4IIEDw3AffwYZrlH3G+K8UVDN5TQBADAL/bM8OHPDDUcf3G/47U0FlLkhK8GKss30EcHAAAtAhB/otKDkIkwtyBhI76ABBfXXQhRy21wG4AeATBRTRPhKwwQRgLUJdeIAnQJcEOGyPDEPQxjiiAA8DqmkfvpFeZT4BAHqAjmsyAEAFbtAMYXhvQ5ew2ib/IAQV2XyQMl1Iw+dC9w85fKMOwfNELw7gwvVEK3+bitDsojE8GSRhBALJYITyV0QlKIEDK5vR7LABAAcMBAEaCEIVybMJprgqJYLToicq0IEDEAQNwXOGl/wBsRDs6D4aoMc/5tC8gQCjCRrw3IIa6BKTRIR3PDFFJVR2nTU8C4uY3MlVFHQSjYXyILUB1VUywclTYmUTllQbQ1zJE2RdIhMOyeMp32KKpo1Ik7QECSnD5ag4zCmYAyGjQcLSy0Mi0zLQvBcHJMUBSjptXAQJwfnw88zX9EiGB+EcLeFkyoLAiWnITICxxEmQyYATk7+phDVhgp9KsCxpmSgTU8qJ/5A1gPJnu4lDJ7FDkNvwLkTHHImk3hmxNP0zJJVIky/39RtmYoUfSoDQnSYqLYr8BpfzBEluBnJEX/kDKQTgaKhIOktz7UM6CuInT/Szm31UIlLSesuWwuIzvewqLOxU0530EwcCyHQ25rmELEW0mz/UZDJL1ctvXgIVQ3lpEw75kEDs6SWKPMhLLWmJJ72UgE1CajosiWpW/hAWm15SLJUwRUgBZBChEECXPUFPS0YpHbze5z/oyZVmnqVQlGDGreoZa5BIBRFSVmWBNjFKJjigLxoxRTDVsVBB3uIjXwGJMzAaTEs245JvarZJgyIIZyoBoRDMFaxpYQlCzJNQijWg5yyrUimshEPY3YAKPbaN7bYEwpVMvLZgoKJISyhiUdm6kgNYDMuoBJvMbZ7yJPjLrpoCAgAh+QQFHgD/ACw4ADEANAA5AAAI/wD/CRxIsKDBgYsOKlzIsOFBew4jSnTYTdPEixeHDFSFsaPDFysQ/Pu1JIzJME6ceFz574CudQIVAJg5UwXLjiOYxRs4gIJPRRnc3cQoAECUF3MqmGjHtN2HLzzWDI3YpcOKOQCAPKDJFcCuqQ6bATiAtY8GfHtgvaPDqK0jsAxHEBtb9h80ALPgTpQDQAxZAH2GwOsKQJfeheMiyPnbJw2AUyiQYdCiBUXDTfwyZ2a5GCsQZ0QEsuhxOGJnwBEk+fGT7J60150WZkoFRQm/NV44M/Z0qFo1ZgA+VPvAYuGFAgUsYWE1SHfdVf+CzWzlcBDy6zp0A4MX5Ve2RvfmLf9gRn2hFyWYOL0504+KboEIRM0D0IOcP2QAbjGQeOnS+39D8PGFGbn944U48/ygEGZ6kUGGQBAd5M9Cg7DyRipx7ANXQhitccZ1loBywVTdJNJRCG+wcl0BqQzVDXQrbVKJIAGwYspN3aTg0RqZFBRCaRNB0c8olfgH5ET+BHDdKxf0eKRD+wwCw4pvPClRJhe8ghwmVjLEwY8CXUKACJt0qdAlr7BygZFmMqTHdWegUmCbB3HwBpVl0knQnKh8WAAMCehJEBQ65HlJKv1AIehAHPRTwBlxDJTnov9AgQVyWHBJqUAFxuFnAYNMSCltAm2iA3KjUOqPIAX0QwCnqQT7EOiiaCJnSSUDsUlnJmXuQwmmqGyqh4UCoYgcDJPS+celBbj3Dz8BWKIonWvc+I8eliSH6z/7KKFnHK/0Y+0oyLHiZJsFWlfAKFIloGUBnLS5jx6URJrJlJYE+w8HMIySbGlrTPjmugJRgdwref5hpSmDvGLvlKxw8I+7yI041RpSTegFBxdwojCrLAqkrrNQWAKDnFP1eYam5BaAqxLZBiCVEpeCAiYq/7I0sLMGF6DoJir2U+YaShagL1jbQoGcs8cVIIiBLb9a6SuYzApWpP80HW+l2ab6T88iCCTxk1oLRMClAUhcyRuCbNslJsg9/Y8pOrxBxdhtBgQAIfkEBR4A/wAsDwAdACsATQAACP8A/wkcONALwYMIEypcOFAPFIYQIyaMY6mAiEsSM0LkVKDjKw4aQyJcQ6ViAVaVRKocSIBVR04rM17S8VDgH0qvMMaMiKkjJVMCL4XYGXHNm44FLIngRzTjGkwuOwZY0zQjPxEVa1ZVyGETQVOcqG5NuOYVDBFKxI5dGAdpAUpQEqxVaOpNP7cE5i40JQhGAVBy9RI0OHCTHj2CD2KiEodp4pFnOsLQcSHT44EhsLgtkOqywDVxUr2JqsTzQX4EUqk1zZqgiEGpUHVd/ThqR0txWGtGasmyaVMELgwK8IZ26+PIB55ZvvxC682CnrsV0ZqfdeuBkyPfxCEOFEzGBev/AOU3KUjTtjuiYh0ABqU3glKd9xwiRPjWazKh0umZHypBZ7iUl2cJRDYda6/cdsYo65mGyRuYxMGfaf4clABQx/2Ryiv9+HYZaKOUx5lpIdzVERavIGbaUayMEsd9esUhyHybpJJdYoT981RkVLRGACVIseLVZf5cYNJbA3pWSUdngCfQkJeJIMiQXmACg4eJqZXAIFJN+BgHCXakg5eCKRGVJalUSOZcm4DyV0r/ZHJGkokp8cYfNrmJBZym/eFmAf1g6Fkmf7KCIQf7XJZKR4YKlAkMrwgqGCeBBgVkAcVd5tg/HJ1kWQilXYYKUg2+Yckom861j4HR/bMkoEPBh7iTKWdkuoaBnXHqYo5b7RPYBUxixI9LWOC5SYVrJRBVgz1hKhAlAVCR6FaXCIIFJQL5E2ZeJRYAg1yYcKLHjStx4FhbBZyB0agFjCKQDh2FupUIHeVKbwEqJtjbWpkI8oplZRWABUj7uCmkXudRlC5IcWh2xnwI6yFCj/8Q4BNySowC3z8BAQAh+QQFHgD/ACwaAA0AQgBPAAAI/wD/CRxIsKBBgV7WCFQCipUggVAKFKBysKLFixgL7uN0ZpRADpYKePwXsUCqjChTHgSxKdu/BDAKgLr070+/AmdAkJRIUaXPjMr0vDrjTyAliXH+rTlTAEaCnSZ/SrUIIoBEAgIx8fyn7FUBLByg9pw6dR+mpP8uSNQhMI7EAF7+jfoaVgknQZXITv3j9Q3NEKC+mvq3jymrEP+UVMoUV6/jTUwLYBLISeLDf1SoKHHM+aPCf3pCgkKcCUuBADQ7q8bU76TSN5YFCoLyVHVnJSEtoRJYKWS/TLaDU5YII+w/EWegFBX+GG2CowUo0dy0jznnTa9YYf1n6maBC9Y7e/8RIRHLdgKWOKUO7/gSdCy7/xln35kf7AKs8tIPHsLqK377CbfPKIgFaOCBU0GB4IIMNujggxBGKOGEFKaUzRQuHXRhhhQ+4dMUEtpAlogNgsiZiRWmKBCJwrFonYsthgcjczOqaKOKHN6oY0Yg9FiQhzv+06NOkxQ5iYNGFumjQUP2mGSNAbZgZDZLFtQkCMoYieKCQiRZpZVDHllkjgga4eWQTIZp5IMunPmlQE1ms6aDkEzZZJpOztngM0XyOKRLfTqIhp1vVhRogx24udKQyvxzKINcCDRJo1Qx6uijCJ5gpDJ3gikkkZNsiWAhY16Jp49FQmngpIUOdGWWRyJXWSSnrX4a55GiBuiDkVfq5KmlDuYxK5xoqkSmg74GqayBqirbbJDPTnXFsgZZgGCuUmEboDkjSqhtRU/EOuGGFZFLrXWNnavuuuy26+678MYrr7zpEhQQACH5BAUyAP8ALA8ADQBdAF0AAAj/AP8JHEiwoMGDBidlEwgiQYI1Ar1s2gTxn79NCbwIzKYQocePIEOKHJhtzb5LApVNvDTpH4iJFddMBMEwwT6aI3PqzJlNWctJCTAuVBZ030KJFAVemilQ5iZ/KZXtnEr1XzYQ+4z+m7R0E81s+zBKffnUalep2c5uvZTgktSqcEGCZWoR5tawm6QihQhU6NaJCYYGTfC2ZdzDXtZA/ef0Zt1NjrtC9XfpEkQvg5uuVLrZpeXDcBtCpol5IlTRGS2uAYGTIGt/i7teDlqW8crWoHOWTvqvK8relxbr9EJZo9MEEWlXzC0ShEbbGGlehPwcNAinFbsmwLmmOvOC1zf9/8ba2bL33Nc1kq0tM4Hw7wOns5/oFb5H3wL90f5tf6D22A/h1t9AXrCl0W6O2UdcRHg5tuCAHtFEXnQRXSJgVZg9lB99/EEIkmi1iWbhYSB0xZtMI3ookj8nJUffeVRNqKFLKurE2j9IYfTeVK3JuGONI4HoHoFUrbFcadsBSdV0i5VYW07TXfIcVjAqORJsLmJUJUJOArallVOtQRtFF35UIH0zggmXUxgt11x8+6kZlxdhJcnQlwwux2JqcsJV3EAmdXhQY4t5UWafS+L1pEET3oYoemzqaKaYaB76KJRopvihbJeCFlaCHnnhHWWWUmVAFXgsIoUHAv0ixSJ4VP9hwHcgCJeYlOA5FByeVBURyS9DhDTEL5EU8V1ieAkqH2Sr5fZIKVWV8ghibNFHYXyK2nXYMKBxG5eibRlqEGWD8QqSN4swt4ixVV20T3eMumZkXCl0A98QKYSGm7iMBVdqTtbYa1831pBILlS72dRsVQFDSDBVBWaL0nocVpWIwA4nQtWYmxF3yT60/ThSup3ep+tq3tW6RnBU2VPyR7WaS5UmGL8Ms6EFVgbbjVOp0k3NHv2MsdAhAb2TPyuD3BbHi+b0i9BEEwT11P8QHbVBV+9k4kTZTiRzQatM/XNBYpdd9dgHRb3KTmw6tE9iK9v070E+U4312QKVjTbWe6v/stN1ijk3t0iliB300GanPTW0L+eS+EB666341LmA5tDlbuZky+N5R24431Pb8rfSblsrHlU0cA651ZKTbTgNUzFtuqAjpW436J4brTfsNjJd6+9fF0TN567nvvfqYlPztz+/+xP8R47fjrzxRncOdeUk1oo0vDsVLr31rKs+/c+M51SiYsxj5RB9IoNUN9R84322+OD/7LdOkS5teuYihf291Pb63PEAmLWcbA0ylzuJpnTyi/lVr3Pzmx5C/heSWlUGZOJhHvPi4jf4TdCD4Ptg3u4XGu8YamE6oRkI43e8FQIwb5pY3kFutT7+icRlHhqgTthykg26hGm0G5nN/8bFsRmNSWEWe2CnGsKx35gkcIcJ2xDBE7ch0cg17RNJw4ZYq4LwiyCUCcvgELJF5nSjBFWRybtERhwMdqYq6PrOrGIELhQyxHTv6pYeQ1Mt+uwDPHXahw9B86xoTQs0SMML/ygjHFLlxldPKxqx2BWXLuZnZRfqEaVsCJdTyWMR5fCAvTzwKnnIijlMXOBHTFKpKeIPTYM8SHj8aEdXgoRF1gLVoACzsCzakiHcoY0VuaQzhohpjDYzCU6cxEkwYotrvpzidIYZy1uOSZe/BJS1mukR/XBIQtkcCE68+cYgDWYx+uFmyT6DowYhMz8J8maaptilipRomDEaUzQRlf+w5byTiIBB5/M8JK5G7VMk/0kOPvt0HZswBC92OsxSmuTOS+XoN95Up438wz6XHJRWz2GTPT/KNvpU5FP/bFdQcKKdlJovTtDZhHogxFKuSWg/Lr2S3H6orY9Vc04mQZhy8rNTFfnwODdlyhd5RJPGcAYyTVITiBbjVPWpMiQH4+mQQKTRAVFmNDxNCllSszJ43UhCSBsRfnrTmfbUEkzO2xCFpvPHf+AFKmKakSIfI8jHJOk6JK0Rp9jKG9o0tTx2QRJp9mrLe04mZDgqF3RispkJxeQhgVVTJgTyh4nwY7Od3cRn/xGCiYSAs54VSGk3cdp/bDacBcnEH0LQ2tAf8kO1pkWtaEHLjxD8AbYjyUQIeotb1gpEuL19LZACAgA7", 'base64');
	response.writeHead(200, {'Content-Type': 'image/gif' });
    response.end(img, 'binary');
}

// 傳遞 request handler 
start(route, handlers);
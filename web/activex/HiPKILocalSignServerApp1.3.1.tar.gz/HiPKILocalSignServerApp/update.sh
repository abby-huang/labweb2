#!/bin/bash
#export http_proxy=10.160.3.88:8080
wget -O temp.sha256 -o /dev/null http://api-hisecurecdn.cdn.hinet.net/HiPKILocalSignServer/update/linux/x64/HiPKILocalSignServer.tar.gz.sha256
#wget --ca-certificate=GRCA2.crt -O temp.sha256 -o /dev/null http://192.168.111.1:8080/linux/HiPKILocalSignServer.tar.gz.sha256
if ! [ $? -eq 0 ]; then
	wget --ca-certificate=HiPKILocalSignServer/GRCA2.crt -O temp.sha256 -o /dev/null https://gpkiapi.nat.gov.tw/HiPKILocalSignServer/update/linux/x64/HiPKILocalSignServer.tar.gz.sha256
	if ! [ $? -eq 0 ]; then
		echo "Download digest file failed"
		read -p "Press enter to continue"
		exit $?
	fi
fi
	echo "Successful download digest file"
diff temp.sha256 HiPKILocalSignServer.tar.gz.sha256 > /dev/null
if [ $? -eq 0 ]; then
	echo "No update available"
	rm temp.sha256
	echo "Update end"
	read -p "Press enter to continue"
	exit 0
fi
echo "Update available!"
read -p "Do you want to update?" yn
if [ "${yn}" != "Y" ]&&[ "${yn}" != "y" ]; then
	echo "User terminate"
	read -p "Press enter to continue"
	exit 0
fi
wget -O HiPKILocalSignServer.tar.gz -o /dev/null http://api-hisecurecdn.cdn.hinet.net/HiPKILocalSignServer/update/linux/x64/HiPKILocalSignServer.tar.gz
if ! [ $? -eq 0 ]; then
	wget --ca-certificate=HiPKILocalSignServer/GRCA2.crt -O HiPKILocalSignServer.tar.gz -o /dev/null https://gpkiapi.nat.gov.tw/HiPKILocalSignServer/update/linux/x64/HiPKILocalSignServer.tar.gz
	if ! [ $? -eq 0 ]; then
		echo "Download update file failed"
		read -p "Press enter to continue"
		exit $?
	fi
fi
echo "Successful download update file"
openssl dgst -sha256 -out caculated.sha256 HiPKILocalSignServer.tar.gz 
diff temp.sha256 caculated.sha256 > /dev/null
isMatch=$?
rm caculated.sha256
echo $isMatch
if [ $isMatch -eq 0 ]; then
	echo "Digest verified"
else
	echo "Unable to verify file"
	read -p "Do you want to continue update?" yn
	if [ "${yn}" != "Y" ]&&[ "${yn}" != "y" ]; then
		echo "User terminate"
		read -p "Press enter to continue"
		exit 0
	fi
fi

kill $(pidof node) > /dev/null
tar xvfz HiPKILocalSignServer.tar.gz > /dev/null
rm HiPKILocalSignServer.tar.gz
if [ $? -eq 0 ]; then
	echo "Successful update file"
else
	echo "Update file failed"
	read -p "Press enter to continue"
	exit $?
fi

mv temp.sha256 HiPKILocalSignServer.tar.gz.sha256
echo "Update end"
read -p "Press enter to continue"


GPKI cross browser component for smartcard digital signature

Use StartServer or start.sh to start the component with Terminal screen.
Use StartServerInvisible to start the component without Terminal screen.
Use StopServer to stop the component.
Use Update or update.sh to check if there is update for the component.
Use SelfTest or browse http://localhost:61161/selfTest.htm to check if the component works fine.
